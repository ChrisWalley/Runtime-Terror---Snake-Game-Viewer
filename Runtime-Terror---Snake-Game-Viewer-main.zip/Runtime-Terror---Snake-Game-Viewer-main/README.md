# Snake Game Viewer

Branch main: 

[![Build Status](https://www.travis-ci.com/ChrisWalley/Runtime-Terror---Snake-Game-Viewer.svg?branch=main)](https://www.travis-ci.com/ChrisWalley/Runtime-Terror---Snake-Game-Viewer)

[![Coverage Status](https://coveralls.io/repos/github/ChrisWalley/Runtime-Terror---Snake-Game-Viewer/badge.svg?branch=main)](https://coveralls.io/github/ChrisWalley/Runtime-Terror---Snake-Game-Viewer?branch=main)


View it here: http://walleyco.de:3000/

![image](https://user-images.githubusercontent.com/19406443/120919333-50b1a180-c6b9-11eb-8bb1-ef7be791c0b5.png)

Previous UI:


![Capture](https://user-images.githubusercontent.com/19406443/119340146-69ba5b80-bc92-11eb-980f-dc16389e8568.PNG)


![Screen Capture](https://user-images.githubusercontent.com/19406443/117628485-7fe7f800-b179-11eb-8c40-95374b5b5a23.PNG)


![Capture](https://user-images.githubusercontent.com/19406443/114347236-ecfd7300-9b64-11eb-9372-2f828fb7e95a.PNG)

